
$(document).ready(function(){

    $('.dropdown-content .cerca[material="all"]').addClass




}
